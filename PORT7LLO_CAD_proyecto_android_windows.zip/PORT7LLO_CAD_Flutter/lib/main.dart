
import 'dart:convert';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

void main() => runApp(const Port7lloCadApp());

const navy = Color(0xFF101A2A);
const panel = Color(0xFF18263A);
const gold = Color(0xFFD6A94B);
const canvasColor = Color(0xFFF4F6F8);

class Port7lloCadApp extends StatelessWidget {
  const Port7lloCadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PORT7LLO CAD',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold,
          brightness: Brightness.dark,
          surface: panel,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      home: const AppShell(),
    );
  }
}

enum CadTool { select, wall, outlet, light, switcher, panel }

extension CadToolLabel on CadTool {
  String get label => switch (this) {
        CadTool.select => 'Seleccionar',
        CadTool.wall => 'Pared',
        CadTool.outlet => 'Tomacorriente',
        CadTool.light => 'Luminaria',
        CadTool.switcher => 'Interruptor',
        CadTool.panel => 'Tablero',
      };
  IconData get icon => switch (this) {
        CadTool.select => Icons.ads_click,
        CadTool.wall => Icons.horizontal_rule,
        CadTool.outlet => Icons.power,
        CadTool.light => Icons.lightbulb_outline,
        CadTool.switcher => Icons.toggle_on_outlined,
        CadTool.panel => Icons.electrical_services,
      };
}

class CadElement {
  CadElement({
    required this.type,
    required this.x,
    required this.y,
    this.x2,
    this.y2,
    this.circuit = 'C1',
    this.voltage = 120,
    this.amps = 20,
    this.wire = '12 AWG',
    this.protection = 'Termomagnético',
    this.board = 'TD-1',
    this.loadVa = 180,
  });

  String type;
  double x;
  double y;
  double? x2;
  double? y2;
  String circuit;
  int voltage;
  int amps;
  String wire;
  String protection;
  String board;
  double loadVa;

  Map<String, dynamic> toJson() => {
        'type': type, 'x': x, 'y': y, 'x2': x2, 'y2': y2,
        'circuit': circuit, 'voltage': voltage, 'amps': amps,
        'wire': wire, 'protection': protection, 'board': board, 'loadVa': loadVa,
      };

  factory CadElement.fromJson(Map<String, dynamic> j) => CadElement(
        type: j['type'] ?? 'outlet',
        x: (j['x'] as num).toDouble(),
        y: (j['y'] as num).toDouble(),
        x2: (j['x2'] as num?)?.toDouble(),
        y2: (j['y2'] as num?)?.toDouble(),
        circuit: j['circuit'] ?? 'C1',
        voltage: j['voltage'] ?? 120,
        amps: j['amps'] ?? 20,
        wire: j['wire'] ?? '12 AWG',
        protection: j['protection'] ?? 'Termomagnético',
        board: j['board'] ?? 'TD-1',
        loadVa: (j['loadVa'] as num?)?.toDouble() ?? 180,
      );
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int tab = 0;
  final List<CadElement> elements = [];
  final List<Map<String, dynamic>> boards = [
    {'name': 'TD-1', 'spaces': 12, 'main': 100, 'system': '1F 120/240 V'}
  ];
  String projectName = 'Proyecto sin título';

  Future<void> saveProject() async {
    final data = {
      'app': 'PORT7LLO CAD',
      'schemaVersion': 1,
      'projectName': projectName,
      'elements': elements.map((e) => e.toJson()).toList(),
      'boards': boards,
    };
    final bytes = Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(data)));
    final path = await FilePicker.platform.saveFile(
      dialogTitle: 'Guardar proyecto PORT7LLO CAD',
      fileName: '${projectName.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_')}.port7llo.json',
      type: FileType.custom,
      allowedExtensions: ['json'],
      bytes: bytes,
    );
    if (mounted && path != null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Proyecto guardado.')));
    }
  }

  Future<void> openProject() async {
    final result = await FilePicker.platform.pickFiles(
      dialogTitle: 'Abrir proyecto PORT7LLO CAD',
      type: FileType.custom,
      allowedExtensions: ['json'],
      withData: true,
    );
    if (result == null || result.files.single.bytes == null) return;
    try {
      final data = jsonDecode(utf8.decode(result.files.single.bytes!)) as Map<String, dynamic>;
      final loaded = (data['elements'] as List? ?? [])
          .map((e) => CadElement.fromJson(Map<String, dynamic>.from(e))).toList();
      setState(() {
        projectName = data['projectName'] ?? 'Proyecto importado';
        elements
          ..clear()
          ..addAll(loaded);
        boards
          ..clear()
          ..addAll((data['boards'] as List? ?? []).map((b) => Map<String, dynamic>.from(b)));
        if (boards.isEmpty) {
          boards.add({'name': 'TD-1', 'spaces': 12, 'main': 100, 'system': '1F 120/240 V'});
        }
        tab = 1;
      });
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No se pudo leer ese proyecto.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(projectName: projectName, onNew: () => setState(() { elements.clear(); projectName = 'Proyecto sin título'; tab = 1; }), onOpen: openProject, onEditor: () => setState(() => tab = 1)),
      EditorPage(elements: elements, boards: boards, onSave: saveProject, projectName: projectName),
      BoardsPage(elements: elements, boards: boards, onChanged: () => setState(() {})),
    ];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel,
        indicatorColor: gold.withOpacity(.18),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.folder_open), label: 'Proyectos'),
          NavigationDestination(icon: Icon(Icons.edit_road), label: 'Dibujar'),
          NavigationDestination(icon: Icon(Icons.electrical_services), label: 'Tableros'),
        ],
      ),
    );
  }
}

class BrandHeader extends StatelessWidget {
  const BrandHeader({super.key, this.subtitle = 'Diseño eléctrico profesional'});
  final String subtitle;
  @override
  Widget build(BuildContext context) => Row(
        children: [
          Container(
            width: 46, height: 46,
            decoration: BoxDecoration(color: gold, borderRadius: BorderRadius.circular(13)),
            child: const Icon(Icons.bolt, color: navy, size: 30),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('PORT7LLO CAD', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, letterSpacing: 1.1)),
            Text(subtitle, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.65))),
          ])),
        ],
      );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.projectName, required this.onNew, required this.onOpen, required this.onEditor});
  final String projectName;
  final VoidCallback onNew, onOpen, onEditor;

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
        const BrandHeader(subtitle: 'CAD eléctrico · Android + Windows'),
        const SizedBox(height: 28),
        const Text('Tu espacio de diseño', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('Crea planos, organiza circuitos y administra tableros desde un solo lugar.', style: TextStyle(color: Colors.white.withOpacity(.68))),
        const SizedBox(height: 22),
        _ActionCard(icon: Icons.add_box_outlined, title: 'Nuevo proyecto', detail: 'Comenzar un plano eléctrico desde cero', onTap: onNew),
        _ActionCard(icon: Icons.folder_open, title: 'Abrir proyecto', detail: 'Continuar un archivo .port7llo.json', onTap: onOpen),
        _ActionCard(icon: Icons.draw_outlined, title: 'Ir al editor', detail: 'Abrir el área de dibujo', onTap: onEditor),
        const SizedBox(height: 20),
        const Text('Módulos del proyecto', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        const Wrap(spacing: 8, runSpacing: 8, children: [
          _Pill('Planos eléctricos'), _Pill('Símbolos'), _Pill('Circuitos'), _Pill('Tableros'), _Pill('Cuadro de cargas'), _Pill('S Pen'),
        ]),
        const SizedBox(height: 22),
        Text('Proyecto actual: $projectName', style: TextStyle(color: Colors.white.withOpacity(.55), fontSize: 12)),
        const SizedBox(height: 12),
        const Text('Versión inicial 0.1.0 · El dimensionamiento normativo automático se incorporará en una etapa posterior.', style: TextStyle(color: Colors.white38, fontSize: 11)),
      ]);
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({required this.icon, required this.title, required this.detail, required this.onTap});
  final IconData icon; final String title, detail; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          leading: CircleAvatar(backgroundColor: gold.withOpacity(.16), child: Icon(icon, color: gold)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(detail, style: const TextStyle(fontSize: 12)),
          trailing: const Icon(Icons.chevron_right, color: gold),
          onTap: onTap,
        ),
      );
}

class _Pill extends StatelessWidget {
  const _Pill(this.text); final String text;
  @override
  Widget build(BuildContext context) => Chip(label: Text(text, style: const TextStyle(fontSize: 11)), side: BorderSide(color: gold.withOpacity(.3)), backgroundColor: panel);
}

class EditorPage extends StatefulWidget {
  const EditorPage({super.key, required this.elements, required this.boards, required this.onSave, required this.projectName});
  final List<CadElement> elements;
  final List<Map<String, dynamic>> boards;
  final Future<void> Function() onSave;
  final String projectName;
  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  CadTool tool = CadTool.select;
  int? selected;
  Offset? wallStart;
  double scale = 1;

  void canvasTap(Offset point) {
    setState(() {
      if (tool == CadTool.select) {
        selected = _hitTest(point);
      } else if (tool == CadTool.wall) {
        if (wallStart == null) {
          wallStart = point;
        } else {
          widget.elements.add(CadElement(type: 'wall', x: wallStart!.dx, y: wallStart!.dy, x2: point.dx, y2: point.dy));
          wallStart = null;
        }
      } else {
        final type = switch (tool) {
          CadTool.outlet => 'outlet',
          CadTool.light => 'light',
          CadTool.switcher => 'switch',
          CadTool.panel => 'panel',
          _ => 'outlet',
        };
        widget.elements.add(CadElement(type: type, x: point.dx, y: point.dy, board: widget.boards.first['name'] as String));
        selected = widget.elements.length - 1;
      }
    });
  }

  int? _hitTest(Offset p) {
    for (int i = widget.elements.length - 1; i >= 0; i--) {
      final e = widget.elements[i];
      if ((Offset(e.x, e.y) - p).distance < 22) return i;
    }
    return null;
  }

  void deleteSelected() {
    if (selected == null) return;
    setState(() { widget.elements.removeAt(selected!); selected = null; });
  }

  @override
  Widget build(BuildContext context) {
    final compact = MediaQuery.sizeOf(context).width < 700;
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 8), child: Row(children: [
        const Icon(Icons.bolt, color: gold),
        const SizedBox(width: 8),
        Expanded(child: Text(widget.projectName, style: const TextStyle(fontWeight: FontWeight.bold), overflow: TextOverflow.ellipsis)),
        IconButton(tooltip: 'Guardar proyecto', onPressed: widget.onSave, icon: const Icon(Icons.save_outlined)),
        IconButton(tooltip: 'Eliminar elemento', onPressed: deleteSelected, icon: const Icon(Icons.delete_outline)),
      ])),
      SizedBox(
        height: 64,
        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 10), children: [
          for (final t in CadTool.values)
            Padding(padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 5), child: ChoiceChip(
              selected: tool == t,
              label: Text(t.label, style: const TextStyle(fontSize: 11)),
              avatar: Icon(t.icon, size: 17, color: tool == t ? gold : null),
              onSelected: (_) => setState(() { tool = t; wallStart = null; }),
            )),
        ]),
      ),
      Expanded(
        child: Container(
          margin: const EdgeInsets.fromLTRB(10, 4, 10, 8),
          decoration: BoxDecoration(color: canvasColor, borderRadius: BorderRadius.circular(12)),
          clipBehavior: Clip.antiAlias,
          child: LayoutBuilder(builder: (context, c) {
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapDown: (d) => canvasTap(d.localPosition),
              child: CustomPaint(
                size: Size(c.maxWidth, c.maxHeight),
                painter: PlanPainter(elements: widget.elements, selected: selected, wallStart: wallStart),
              ),
            );
          }),
        ),
      ),
      if (selected != null && selected! < widget.elements.length)
        _PropertiesPanel(element: widget.elements[selected!], boards: widget.boards, onChanged: () => setState(() {})),
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 2, 12, 8),
        child: Row(children: [
          Text('${widget.elements.length} elementos', style: const TextStyle(fontSize: 11, color: Colors.white60)),
          const Spacer(),
          if (wallStart != null) const Text('Toca el segundo punto de la pared', style: TextStyle(color: gold, fontSize: 11)),
          if (!compact) const Text(' · S Pen / mouse / táctil', style: TextStyle(fontSize: 11, color: Colors.white54)),
        ]),
      ),
    ]);
  }
}

class _PropertiesPanel extends StatelessWidget {
  const _PropertiesPanel({required this.element, required this.boards, required this.onChanged});
  final CadElement element;
  final List<Map<String, dynamic>> boards;
  final VoidCallback onChanged;

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity, color: panel,
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('PROPIEDADES DEL ELEMENTO', style: TextStyle(fontSize: 10, color: gold, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(spacing: 10, runSpacing: 8, children: [
            _prop('Circuito', DropdownButton<String>(value: element.circuit, items: List.generate(24, (i) => 'C${i+1}').map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { element.circuit = v!; onChanged(); })),
            _prop('Voltaje', DropdownButton<int>(value: element.voltage, items: const [120, 240].map((v) => DropdownMenuItem(value: v, child: Text('$v V'))).toList(), onChanged: (v) { element.voltage = v!; onChanged(); })),
            _prop('Amperaje', DropdownButton<int>(value: element.amps, items: const [15, 20, 30, 40, 50, 60].map((v) => DropdownMenuItem(value: v, child: Text('$v A'))).toList(), onChanged: (v) { element.amps = v!; onChanged(); })),
            _prop('Conductor', DropdownButton<String>(value: element.wire, items: const ['14 AWG','12 AWG','10 AWG','8 AWG','6 AWG','4 AWG'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { element.wire = v!; onChanged(); })),
            _prop('Protección', DropdownButton<String>(value: element.protection, items: const ['Termomagnético','GFCI','AFCI','Diferencial'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { element.protection = v!; onChanged(); })),
            _prop('Tablero', DropdownButton<String>(value: boards.any((b) => b['name'] == element.board) ? element.board : boards.first['name'], items: boards.map((b) => DropdownMenuItem(value: b['name'] as String, child: Text(b['name'] as String))).toList(), onChanged: (v) { element.board = v!; onChanged(); })),
          ]),
        ]),
      );

  Widget _prop(String label, Widget child) => SizedBox(width: 112, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 10, color: Colors.white60)),
        SizedBox(height: 34, child: child),
      ]));
}

class PlanPainter extends CustomPainter {
  PlanPainter({required this.elements, required this.selected, required this.wallStart});
  final List<CadElement> elements; final int? selected; final Offset? wallStart;
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = const Color(0xFFE1E6EB)..strokeWidth = .6;
    for (double x = 0; x < size.width; x += 20) canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    for (double y = 0; y < size.height; y += 20) canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    for (int i = 0; i < elements.length; i++) {
      final e = elements[i]; final p = Offset(e.x, e.y);
      final active = i == selected;
      final ink = Paint()
        ..color = active ? const Color(0xFFB17B19) : const Color(0xFF20364F)
        ..strokeWidth = 2.5
        ..style = PaintingStyle.stroke;
      if (e.type == 'wall') {
        canvas.drawLine(p, Offset(e.x2 ?? e.x, e.y2 ?? e.y), ink..strokeWidth = 5);
      } else if (e.type == 'outlet') {
        canvas.drawCircle(p, 10, ink);
        canvas.drawLine(p + const Offset(-3,-4), p + const Offset(-3,4), ink);
        canvas.drawLine(p + const Offset(3,-4), p + const Offset(3,4), ink);
      } else if (e.type == 'light') {
        canvas.drawCircle(p, 11, ink);
        canvas.drawLine(p + const Offset(-7,-7), p + const Offset(7,7), ink);
        canvas.drawLine(p + const Offset(-7,7), p + const Offset(7,-7), ink);
      } else if (e.type == 'switch') {
        canvas.drawCircle(p, 9, ink);
        canvas.drawLine(p, p + const Offset(12,-10), ink);
      } else if (e.type == 'panel') {
        canvas.drawRect(Rect.fromCenter(center: p, width: 27, height: 34), ink);
        final tp = TextPainter(text: const TextSpan(text: 'TD', style: TextStyle(color: Color(0xFF20364F), fontSize: 9, fontWeight: FontWeight.bold)), textDirection: TextDirection.ltr)..layout();
        tp.paint(canvas, p - Offset(tp.width/2, tp.height/2));
      }
      if (active) canvas.drawCircle(p, 17, Paint()..color = gold.withOpacity(.3)..style = PaintingStyle.stroke..strokeWidth = 1.5);
      final label = e.type == 'wall' ? '' : e.circuit;
      if (label.isNotEmpty) {
        final tp = TextPainter(text: TextSpan(text: label, style: const TextStyle(color: Color(0xFF31465D), fontSize: 9, fontWeight: FontWeight.bold)), textDirection: TextDirection.ltr)..layout();
        tp.paint(canvas, p + const Offset(13, -6));
      }
    }
    if (wallStart != null) canvas.drawCircle(wallStart!, Paint()..color = gold..style = PaintingStyle.fill);
  }
  @override
  bool shouldRepaint(covariant PlanPainter oldDelegate) => true;
}

class BoardsPage extends StatefulWidget {
  const BoardsPage({super.key, required this.elements, required this.boards, required this.onChanged});
  final List<CadElement> elements; final List<Map<String, dynamic>> boards; final VoidCallback onChanged;
  @override
  State<BoardsPage> createState() => _BoardsPageState();
}

class _BoardsPageState extends State<BoardsPage> {
  void addBoard() {
    final next = widget.boards.length + 1;
    setState(() => widget.boards.add({'name':'TD-$next','spaces':12,'main':100,'system':'1F 120/240 V'}));
    widget.onChanged();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      const BrandHeader(subtitle: 'Administrador de tableros'),
      const SizedBox(height: 20),
      Row(children: [const Expanded(child: Text('Tableros eléctricos', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))), FilledButton.icon(onPressed: addBoard, icon: const Icon(Icons.add), label: const Text('Crear'))]),
      const SizedBox(height: 12),
      for (final b in widget.boards) _boardCard(b),
    ]);
  }

  Widget _boardCard(Map<String, dynamic> b) {
    final name = b['name'] as String;
    final circuits = widget.elements.where((e) => e.board == name).toList();
    final total = circuits.fold<double>(0, (s, e) => s + e.loadVa);
    final grouped = <String, double>{};
    for (final e in circuits) { grouped[e.circuit] = (grouped[e.circuit] ?? 0) + e.loadVa; }
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), const Icon(Icons.electrical_services, color: gold)]),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          _boardSetting('Espacios', DropdownButton<int>(value: b['spaces'] as int, items: [8,12,16,20,24,30,40,42,54,60,72,84].map((v)=>DropdownMenuItem(value:v,child:Text('$v'))).toList(), onChanged:(v)=>setState(()=>b['spaces']=v))),
          _boardSetting('Principal', DropdownButton<int>(value: b['main'] as int, items: [60,70,80,100,125,150,200].map((v)=>DropdownMenuItem(value:v,child:Text('$v A'))).toList(), onChanged:(v)=>setState(()=>b['main']=v))),
          _boardSetting('Sistema', DropdownButton<String>(value: b['system'] as String, items: const ['1F 120/240 V','3F 120/208 V','3F 120/240 V'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(), onChanged:(v)=>setState(()=>b['system']=v))),
        ]),
        const Divider(height: 20),
        Text('Potencia conectada: ${total.toStringAsFixed(0)} VA', style: const TextStyle(fontWeight: FontWeight.bold)),
        Text('${circuits.length} elementos · ${grouped.length} circuitos con carga · ${b['spaces']} espacios nominales', style: const TextStyle(color: Colors.white60, fontSize: 12)),
        if (grouped.isNotEmpty) ...[
          const SizedBox(height: 8),
          for (final entry in grouped.entries) Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Row(children: [Expanded(child: Text(entry.key)), Text('${entry.value.toStringAsFixed(0)} VA', style: const TextStyle(color: gold))])),
        ],
        const SizedBox(height: 6),
        const Text('La ocupación de espacios, asignación física de polos y balance de fases detallados se implementarán en la siguiente etapa.', style: TextStyle(color: Colors.white38, fontSize: 10)),
      ])),
    );
  }

  Widget _boardSetting(String label, Widget child) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(fontSize: 10, color: Colors.white60)),
    SizedBox(height: 36, child: child),
  ]);
}
