# PORT7LLO CAD — proyecto Flutter inicial

Este paquete contiene el código fuente de la aplicación nativa PORT7LLO CAD y una automatización gratuita para compilar Android y Windows usando GitHub Actions.

## Funciones de la base 0.1
- Interfaz profesional oscura y dorada.
- Pantallas de proyectos, editor y administrador inicial de tableros.
- Dibujo básico de paredes y colocación de tomacorrientes, luminarias, interruptores y tableros.
- Propiedades eléctricas por elemento: circuito, voltaje, amperaje, conductor, protección y tablero.
- Guardar y abrir proyectos JSON.
- Base de interacción táctil, mouse y lápiz digital.

## Cómo obtener los instaladores sin instalar Flutter en tu computadora

1. Entra en https://github.com y crea una cuenta gratuita o inicia sesión.
2. Crea un repositorio nuevo llamado `PORT7LLO-CAD`.
3. Descomprime este ZIP en tu computadora. Sube el contenido de la carpeta `PORT7LLO_CAD_Flutter` al repositorio (incluida la carpeta oculta `.github`).
4. En GitHub abre la pestaña **Actions**.
5. Selecciona **Build PORT7LLO CAD** y pulsa **Run workflow**. También se ejecuta automáticamente al subir cambios a la rama `main`.
6. Cuando termine, abre la ejecución y baja los artefactos:
   - `PORT7LLO-CAD-Android-APK`: contiene `app-release.apk`.
   - `PORT7LLO-CAD-Windows`: contiene el paquete ZIP para Windows.
7. Android: copia el APK al teléfono, ábrelo y autoriza la instalación desde esa fuente si Android lo solicita.
8. Windows: extrae el ZIP y ejecuta `port7llo_cad.exe`. Mantén los archivos DLL y carpetas junto al ejecutable.

## Si tienes Flutter instalado localmente

Desde esta carpeta:
```bash
flutter create --platforms=android,windows .
flutter pub get
flutter run
```

Compilar:
```bash
flutter build apk --release
flutter build windows --release
```

## Requisitos y límites actuales

- Esta entrega es el proyecto fuente; no contiene todavía APK ni EXE compilados.
- La compilación remota requiere una cuenta de GitHub y subir el proyecto al repositorio.
- El administrador de tableros es inicial: aún no completa el posicionamiento físico de polos ni un balance de fases validado.
- No se ha ejecutado Flutter build ni pruebas en dispositivos físicos en este entorno.
- Los datos eléctricos y las corrientes son preliminares; no equivalen a un cálculo normativo NEC ni sustituyen la revisión profesional y la normativa adoptada en El Salvador.
